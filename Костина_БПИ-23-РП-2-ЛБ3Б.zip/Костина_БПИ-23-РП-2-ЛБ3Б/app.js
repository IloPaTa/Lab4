const USERS_URL = "https://jsonplaceholder.typicode.com/users";
const POSTS_URL = "https://jsonplaceholder.typicode.com/posts";

//  DOM
const loadUsersBtn  = document.getElementById("loadUsersBtn");
const searchInput   = document.getElementById("searchInput");
const statusMessage = document.getElementById("statusMessage");
const usersList     = document.getElementById("usersList");
const postsArea     = document.getElementById("postsArea");
const postsTitle    = document.getElementById("postsTitle");

//  Состояние
let allUsers = [];
let postsLoading = false;


function setStatus(text, type = "") {
  statusMessage.textContent = text;
  statusMessage.className = "status" + (type ? " " + type : "");
}

function clearPosts() {
  postsArea.replaceChildren();
  postsTitle.textContent = "Публикации";
}


function describeError(error, contextLabel) {
  // HTTP-ошибка: мы сами её бросили с полями status / statusText
  if (error && typeof error === "object" && "httpStatus" in error) {
    return `${contextLabel}\nHTTP-код: ${error.httpStatus} ${error.httpStatusText || ""}`.trim();
  }

  // Сетевая ошибка (fetch не дошёл до сервера)
  if (error && error.name === "TypeError" && /fetch/i.test(error.message)) {
    const isFile = location.protocol === "file:";
    const hint = isFile
      ? "Страница открыта по file:// — браузер блокирует запросы. Запустите локальный сервер: python -m http.server 8000 и откройте http://localhost:8000"
      : "Проверьте подключение к интернету, отключите блокировщик рекламы и повторите попытку.";
    return `${contextLabel}\nСетевая ошибка: ${error.message}\nПодсказка: ${hint}`;
  }

  // Прочие ошибки
  return `${contextLabel}\nОшибка: ${error?.message || String(error)}`;
}

/** Бросает объект-ошибку с HTTP-статусом, чтобы потом его распознать */
function httpError(response) {
  const err = new Error(`HTTP ${response.status} ${response.statusText}`);
  err.httpStatus = response.status;
  err.httpStatusText = response.statusText;
  return err;
}



async function loadUsers() {
  loadUsersBtn.disabled = true;
  setStatus("Загрузка", "loading");
  clearPosts();

  try {
    const response = await fetch(USERS_URL);

    // HTTP 200 — успех, иначе бросаем ошибку с кодом
    if (!response.ok) {
      throw httpError(response);
    }

    const users = await response.json();
    allUsers = users;

    // Применяем текущий фильтр (если пользователь уже что-то ввёл)
    applyFilter();

    setStatus(`Загружено пользователей: ${users.length}. HTTP-код: 200 OK`, "success");
  } catch (error) {
    console.error("Ошибка загрузки пользователей:", error);
    allUsers = [];
    usersList.replaceChildren();
    setStatus(describeError(error, "Не удалось загрузить пользователей."), "error");
  } finally {
    loadUsersBtn.disabled = false;
  }
}



function renderUsers(users) {
  usersList.replaceChildren();

  if (users.length === 0) {
    const empty = document.createElement("p");
    empty.className = "placeholder";
    empty.textContent = allUsers.length === 0
      ? "Сначала нажмите «Загрузить пользователей»"
      : "Пользователи не найдены";
    usersList.appendChild(empty);
    return;
  }

  const fragment = document.createDocumentFragment();

  users.forEach((user) => {
    const card = document.createElement("article");
    card.className = "user-card";

    const info = document.createElement("div");
    info.className = "user-info";

    const nameEl = document.createElement("h3");
    nameEl.textContent = user.name;

    const emailEl = document.createElement("p");
    emailEl.textContent = "Email: " + user.email;

    const cityEl = document.createElement("p");
    cityEl.textContent = "Город: " + (user.address?.city ?? "—");

    info.append(nameEl, emailEl, cityEl);

    const postsBtn = document.createElement("button");
    postsBtn.type = "button";
    postsBtn.textContent = "Показать публикации";
    postsBtn.addEventListener("click", () => loadPosts(user, postsBtn));

    card.append(info, postsBtn);
    fragment.appendChild(card);
  });

  usersList.appendChild(fragment);
}



function applyFilter() {
  const query = searchInput.value.trim().toLowerCase();
  const filtered = query
    ? allUsers.filter((u) => u.name.toLowerCase().includes(query))
    : allUsers;
  renderUsers(filtered);
}


async function loadPosts(user, sourceBtn) {
  if (postsLoading) return;
  postsLoading = true;
  if (sourceBtn) sourceBtn.disabled = true;

  clearPosts();
  postsTitle.textContent = "Публикации пользователя: " + user.name;

  const loadingP = document.createElement("p");
  loadingP.className = "placeholder";
  loadingP.textContent = "Загрузка";
  postsArea.appendChild(loadingP);

  try {
    const url = `${POSTS_URL}?userId=${encodeURIComponent(user.id)}`;
    const response = await fetch(url);

    if (!response.ok) {
      throw httpError(response);
    }

    const posts = await response.json();
    postsArea.replaceChildren();

    if (posts.length === 0) {
      const empty = document.createElement("p");
      empty.className = "placeholder";
      empty.textContent = "У этого пользователя нет публикаций.";
      postsArea.appendChild(empty);
      return;
    }

    posts.slice(0, 3).forEach((post) => {
      const card = document.createElement("article");
      card.className = "post-card";

      const title = document.createElement("h4");
      title.textContent = post.title;

      const body = document.createElement("p");
      body.textContent = post.body;

      card.append(title, body);
      postsArea.appendChild(card);
    });
  } catch (error) {
    console.error("Ошибка загрузки публикаций:", error);
    postsArea.replaceChildren();
    const errorP = document.createElement("p");
    errorP.className = "placeholder";
    errorP.textContent = describeError(
      error,
      "Не удалось загрузить публикации. Нажмите кнопку ещё раз, чтобы повторить."
    );
    postsArea.appendChild(errorP);
  } finally {
    postsLoading = false;
    if (sourceBtn) sourceBtn.disabled = false;
  }
}



loadUsersBtn.addEventListener("click", loadUsers);

searchInput.addEventListener("input", applyFilter);